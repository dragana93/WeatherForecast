package reader;

import java.util.List;
import java.util.ArrayList;

public class Util {

	private final List<XMLItem> items = new ArrayList<XMLItem>();

	public Util() {
	}

	public List<XMLItem> getItems() {
		return items;
	}



}
